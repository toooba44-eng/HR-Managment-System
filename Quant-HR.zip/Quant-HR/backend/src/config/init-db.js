const db = require('./database');

function initDatabase() {
    console.log('🔄 Initializing database...');

    // Users table
    db.exec(`
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'employee' CHECK(role IN ('admin', 'hr_manager', 'department_head', 'employee')),
            is_active INTEGER DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);

    // Departments table
    db.exec(`
        CREATE TABLE IF NOT EXISTS departments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            name_en TEXT,
            description TEXT,
            color TEXT DEFAULT '#3B82F6',
            icon TEXT DEFAULT 'building',
            manager_id INTEGER,
            parent_department_id INTEGER,
            employee_count INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (manager_id) REFERENCES employees(id),
            FOREIGN KEY (parent_department_id) REFERENCES departments(id)
        )
    `);

    // Employees table
    db.exec(`
        CREATE TABLE IF NOT EXISTS employees (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            employee_number TEXT UNIQUE,
            full_name TEXT NOT NULL,
            full_name_en TEXT,
            email TEXT UNIQUE,
            phone TEXT,
            national_id TEXT,
            date_of_birth DATE,
            nationality TEXT DEFAULT 'سعودي',
            marital_status TEXT CHECK(marital_status IN ('أعزب', 'متزوج', 'مطلق', 'أرمل')),
            gender TEXT CHECK(gender IN ('ذكر', 'أنثى')),
            address TEXT,
            emergency_contact_name TEXT,
            emergency_contact_phone TEXT,
            profile_picture TEXT,
            department_id INTEGER,
            job_title TEXT,
            job_level TEXT CHECK(job_level IN ('متدرب', ' junior', 'مبتدئ', 'متوسط', ' senior', 'خبير', 'مدير', 'مدير تنفيذي', 'CEO')),
            manager_id INTEGER,
            hire_date DATE,
            employment_type TEXT DEFAULT 'دوام كامل' CHECK(employment_type IN ('دوام كامل', 'دوام جزئي', 'عقد', 'متعاون')),
            work_location TEXT DEFAULT 'الرياض - المقر الرئيسي',
            team TEXT,
            salary REAL DEFAULT 0,
            allowances REAL DEFAULT 0,
            total_salary REAL DEFAULT 0,
            bank_name TEXT,
            bank_account TEXT,
            iban TEXT,
            contract_type TEXT DEFAULT 'غير محدد' CHECK(contract_type IN ('محدد المدة', 'غير محدد', 'عقد مشروع', 'تدريب')),
            contract_start DATE,
            contract_end DATE,
            notice_period_days INTEGER DEFAULT 30,
            annual_leave_balance REAL DEFAULT 30,
            sick_leave_balance REAL DEFAULT 10,
            emergency_leave_balance REAL DEFAULT 5,
            unpaid_leave_balance REAL DEFAULT 0,
            status TEXT DEFAULT 'نشط' CHECK(status IN ('نشط', 'إجازة', 'معلق', 'مستقيل', 'مفصول')),
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (department_id) REFERENCES departments(id),
            FOREIGN KEY (manager_id) REFERENCES employees(id)
        )
    `);

    // Attendance table
    db.exec(`
        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER NOT NULL,
            date DATE NOT NULL,
            check_in DATETIME,
            check_out DATETIME,
            check_in_location TEXT,
            check_out_location TEXT,
            work_hours REAL DEFAULT 0,
            break_duration INTEGER DEFAULT 60,
            overtime_hours REAL DEFAULT 0,
            status TEXT DEFAULT 'حاضر' CHECK(status IN ('حاضر', 'غائب', 'متأخر', 'إجازة', 'عمل عن بعد', 'مأذون')),
            notes TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (employee_id) REFERENCES employees(id)
        )
    `);

    // Leaves table
    db.exec(`
        CREATE TABLE IF NOT EXISTS leaves (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER NOT NULL,
            type TEXT NOT NULL CHECK(type IN ('سنوية', 'مرضية', 'طارئة', 'بدون راتب', 'أمومة', 'حج', 'دراسية', 'استثنائية')),
            start_date DATE NOT NULL,
            end_date DATE NOT NULL,
            days_count REAL NOT NULL,
            reason TEXT,
            status TEXT DEFAULT 'معلقة' CHECK(status IN ('معلقة', 'موافقة', 'مرفوضة', 'ملغاة')),
            approved_by INTEGER,
            approved_at DATETIME,
            rejection_reason TEXT,
            attachments TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (employee_id) REFERENCES employees(id),
            FOREIGN KEY (approved_by) REFERENCES employees(id)
        )
    `);

    // Documents table
    db.exec(`
        CREATE TABLE IF NOT EXISTS documents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER NOT NULL,
            type TEXT NOT NULL CHECK(type IN ('هوية', 'جواز سفر', 'عقد عمل', 'شهادة', 'سيرة ذاتية', 'تقرير طبي', 'صورة شخصية', 'مستند آخر')),
            title TEXT NOT NULL,
            file_path TEXT,
            file_size INTEGER,
            mime_type TEXT,
            uploaded_by INTEGER,
            uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (employee_id) REFERENCES employees(id),
            FOREIGN KEY (uploaded_by) REFERENCES employees(id)
        )
    `);

    // Contracts table
    db.exec(`
        CREATE TABLE IF NOT EXISTS contracts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER NOT NULL,
            contract_type TEXT NOT NULL,
            start_date DATE NOT NULL,
            end_date DATE,
            salary REAL NOT NULL,
            allowances REAL DEFAULT 0,
            benefits TEXT,
            notice_period_days INTEGER DEFAULT 30,
            probation_period_days INTEGER DEFAULT 90,
            document_path TEXT,
            status TEXT DEFAULT 'ساري' CHECK(status IN ('ساري', 'منتهي', 'مُجدد', 'مُلغى')),
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (employee_id) REFERENCES employees(id)
        )
    `);

    // Activity log
    db.exec(`
        CREATE TABLE IF NOT EXISTS activity_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            action TEXT NOT NULL,
            entity_type TEXT,
            entity_id INTEGER,
            details TEXT,
            ip_address TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    `);

    // Create indexes for performance
    db.exec(`CREATE INDEX IF NOT EXISTS idx_employees_department ON employees(department_id)`);
    db.exec(`CREATE INDEX IF NOT EXISTS idx_employees_manager ON employees(manager_id)`);
    db.exec(`CREATE INDEX IF NOT EXISTS idx_attendance_employee_date ON attendance(employee_id, date)`);
    db.exec(`CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance(date)`);
    db.exec(`CREATE INDEX IF NOT EXISTS idx_leaves_employee ON leaves(employee_id)`);
    db.exec(`CREATE INDEX IF NOT EXISTS idx_leaves_status ON leaves(status)`);
    db.exec(`CREATE INDEX IF NOT EXISTS idx_documents_employee ON documents(employee_id)`);

    console.log('✅ Database initialized successfully');
}

module.exports = initDatabase;
