# Quant HR - نظام إدارة الموارد البشرية

## 🚀 Quick Start

### 1. إنشاء المشروع
انسخ الملفات من `Quant-HR-COMPLETE.txt` إلى المسارات المقابلة.

### 2. تشغيل Backend
```bash
cd Quant-HR/backend
npm install
cp .env.example .env
npm run migrate
npm run seed
npm run dev
```

### 3. تشغيل Frontend (Terminal جديد)
```bash
cd Quant-HR/frontend
npm install
npm run dev
```

### 4. فتح التطبيق
افتح المتصفح على: `http://localhost:5173`

## 🔐 بيانات الدخول التجريبية

| البريد | كلمة المرور | الدور |
|--------|-------------|-------|
| admin@quant.com | admin123 | Admin |
| mohamed.tech@quant.com | password123 | Department Head |
| khaled.dev@quant.com | password123 | Employee |

## 📁 هيكل المشروع

```
Quant-HR/
├── backend/
│   ├── src/
│   │   ├── config/       # Database, Migrations, Seed
│   │   ├── middleware/   # Auth, Validation, Error Handler
│   │   ├── routes/       # API Endpoints
│   │   └── server.js     # Entry Point
│   ├── database/         # SQLite Database
│   └── package.json
├── frontend/
│   ├── src/
│   │   ├── components/   # Reusable Components
│   │   ├── pages/        # Page Components
│   │   ├── hooks/        # Custom Hooks
│   │   ├── context/      # React Context
│   │   └── utils/        # Helpers
│   └── package.json
└── package.json
```

## 📡 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/auth/login | تسجيل الدخول |
| GET | /api/employees | قائمة الموظفين |
| GET | /api/employees/:id | بروفايل موظف |
| POST | /api/employees | إضافة موظف |
| GET | /api/departments | قائمة الإدارات |
| GET | /api/departments/org-chart/tree | الهيكل التنظيمي |
| GET | /api/attendance | سجل الحضور |
| POST | /api/attendance/checkin | تسجيل دخول |
| POST | /api/attendance/checkout | تسجيل خروج |
| GET | /api/leaves | طلبات الإجازات |
| POST | /api/leaves | طلب إجازة جديدة |
| PUT | /api/leaves/:id/approve | موافقة/رفض إجازة |
| GET | /api/dashboard/stats | إحصائيات لوحة التحكم |

## 🛠️ Technologies

- **Backend:** Node.js, Express, SQLite, JWT
- **Frontend:** React, Tailwind CSS, Recharts, Zustand
- **Database:** SQLite (better-sqlite3)

## 📄 License

MIT License
